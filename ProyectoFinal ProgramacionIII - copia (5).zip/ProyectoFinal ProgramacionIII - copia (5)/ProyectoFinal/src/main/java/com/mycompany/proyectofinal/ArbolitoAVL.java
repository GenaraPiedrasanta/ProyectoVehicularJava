/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectofinal;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;

/**
 *
 * @author Piedrasanta
 */

public class ArbolitoAVL {
    NodoAvl raiz;

    public ArbolitoAVL() {
        raiz = null;
    }

    private int altura(NodoAvl nodo) {
        return (nodo == null) ? 0 : nodo.altura;
    }

    private int max(int a, int b) {
        return (a > b) ? a : b;
    }

    private int getBalance(NodoAvl nodo) {
        return (nodo == null) ? 0 : altura(nodo.hijoIzquierdo) - altura(nodo.hijoDerecho);
    }

    private NodoAvl rotacionDerecha(NodoAvl y) {
        if (y == null || y.hijoIzquierdo == null) return y;

        NodoAvl x = y.hijoIzquierdo;
        NodoAvl T2 = x.hijoDerecho;

        x.hijoDerecho = y;
        y.hijoIzquierdo = T2;

        y.altura = max(altura(y.hijoIzquierdo), altura(y.hijoDerecho)) + 1;
        x.altura = max(altura(x.hijoIzquierdo), altura(x.hijoDerecho)) + 1;

        return x;
    }

    private NodoAvl rotacionIzquierda(NodoAvl x) {
        if (x == null || x.hijoDerecho == null) return x;

        NodoAvl y = x.hijoDerecho;
        NodoAvl T2 = y.hijoIzquierdo;

        y.hijoIzquierdo = x;
        x.hijoDerecho = T2;

        x.altura = max(altura(x.hijoIzquierdo), altura(x.hijoDerecho)) + 1;
        y.altura = max(altura(y.hijoIzquierdo), altura(y.hijoDerecho)) + 1;

        return y;
    }

    private NodoAvl insertar(NodoAvl nodo, Vehiculo v) {
        if (nodo == null) {
            return new NodoAvl(v);
        }

        if (v.getPlaca().compareTo(nodo.dato.getPlaca()) < 0) {
            nodo.hijoIzquierdo = insertar(nodo.hijoIzquierdo, v);
        } else if (v.getPlaca().compareTo(nodo.dato.getPlaca()) > 0) {
            nodo.hijoDerecho = insertar(nodo.hijoDerecho, v);
        } else {
            return nodo; // Placa repetida
        }

        nodo.altura = 1 + max(altura(nodo.hijoIzquierdo), altura(nodo.hijoDerecho));
        int balance = getBalance(nodo);

        // Casos de desbalance

        // Izquierda Izquierda
        if (balance > 1 && v.getPlaca().compareTo(nodo.hijoIzquierdo.dato.getPlaca()) < 0) {
            return rotacionDerecha(nodo);
        }

        // Derecha Derecha
        if (balance < -1 && v.getPlaca().compareTo(nodo.hijoDerecho.dato.getPlaca()) > 0) {
            return rotacionIzquierda(nodo);
        }

        // Izquierda Derecha
        if (balance > 1 && v.getPlaca().compareTo(nodo.hijoIzquierdo.dato.getPlaca()) > 0) {
            nodo.hijoIzquierdo = rotacionIzquierda(nodo.hijoIzquierdo);
            return rotacionDerecha(nodo);
        }

        // Derecha Izquierda (corregido)
        if (balance < -1 && v.getPlaca().compareTo(nodo.hijoDerecho.dato.getPlaca()) < 0) {
            nodo.hijoDerecho = rotacionDerecha(nodo.hijoDerecho);
            return rotacionIzquierda(nodo);
        }

        return nodo; // Sin desbalance
    }

    public void insertar(Vehiculo v) {
        raiz = insertar(raiz, v);
    }
    //Recorridos
    public void inOrden() {
        inOrden(raiz);
    }

    private void inOrden(NodoAvl nodo) {
        if (nodo != null) {
            inOrden(nodo.hijoIzquierdo);
            System.out.println(nodo.dato.getPlaca() + " - " + nodo.dato.getMarca());
            inOrden(nodo.hijoDerecho);
        }
    }
    public void preOrden() {
    preOrden(raiz);
}

private void preOrden(NodoAvl nodo) {
    if (nodo != null) {
        System.out.println(nodo.dato.getPlaca());
        preOrden(nodo.hijoIzquierdo);
        preOrden(nodo.hijoDerecho);
    }
}

public void postOrden() {
    postOrden(raiz);
}

private void postOrden(NodoAvl nodo) {
    if (nodo != null) {
        postOrden(nodo.hijoIzquierdo);
        postOrden(nodo.hijoDerecho);
        System.out.println(nodo.dato.getPlaca());
    }
}
    public Vehiculo buscarPorPlaca(String placa){
      return buscarPorPlaca(raiz, placa);
    
}
    private Vehiculo buscarPorPlaca(NodoAvl nodo, String placa) {
    if (nodo == null) return null;

    int cmp = placa.compareTo(nodo.dato.getPlaca());

    if (cmp == 0) return nodo.dato;
    else if (cmp < 0) return buscarPorPlaca(nodo.hijoIzquierdo, placa);
    else return buscarPorPlaca(nodo.hijoDerecho, placa);
}

public void generarDotAVL(NodoAvl nodo, BufferedWriter bw) throws IOException {
    if (nodo != null) {
        if (nodo.hijoIzquierdo != null) {
            bw.write("\"" + nodo.dato.getPlaca() + "\" -> \"" + nodo.hijoIzquierdo.dato.getPlaca() + "\";\n");
            generarDotAVL(nodo.hijoIzquierdo, bw);
        }
        if (nodo.hijoDerecho != null) {
            bw.write("\"" + nodo.dato.getPlaca() + "\" -> \"" + nodo.hijoDerecho.dato.getPlaca() + "\";\n");
            generarDotAVL(nodo.hijoDerecho, bw);
        }
    }
}







}




