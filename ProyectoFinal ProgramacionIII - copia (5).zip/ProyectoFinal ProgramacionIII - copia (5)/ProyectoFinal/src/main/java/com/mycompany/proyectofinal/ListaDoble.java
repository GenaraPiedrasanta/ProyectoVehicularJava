/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectofinal;

import javax.swing.JOptionPane;

/**
 *
 * @author Piedrasanta
 */
public class ListaDoble {
    
    
     NodoDoble cabeza;

    public void insertarAlInicio(String dato) {
        NodoDoble nuevo = new NodoDoble(dato);
        if (cabeza == null) {
            cabeza = nuevo;
        } else {
            nuevo.siguiente = cabeza;
            cabeza.anterior = nuevo;
            cabeza = nuevo;
        }
    }

    public void insertarAlFinal(String dato) {
        NodoDoble nuevo = new NodoDoble(dato);
        if (cabeza == null) {
            cabeza = nuevo;
        } else {
            NodoDoble actual = cabeza;
            while (actual.siguiente != null) {
                actual = actual.siguiente;
            }
            actual.siguiente = nuevo;
            nuevo.anterior = actual;
        }
    }

    public String mostrarLista() {
        if (cabeza == null) {
            return "Lista vacía";
        }

        String lista = "";
        NodoDoble actual = cabeza;
        while (actual != null) {
            lista = lista + actual.dato + " <-> ";
            actual = actual.siguiente;
        }
        lista = lista + "NULL";
        return lista;
    }

    public void eliminarInicio() {
        if (cabeza == null) {
            JOptionPane.showMessageDialog(null, "Lista vacía");
        } else {
            cabeza = cabeza.siguiente;
            if (cabeza != null) {
                cabeza.anterior = null;
            }
            JOptionPane.showMessageDialog(null, "Dato eliminado del inicio");
        }
    }

    public void eliminarFinal() {
        if (cabeza == null) {
            JOptionPane.showMessageDialog(null, "Lista vacía");
        } else if (cabeza.siguiente == null) {
            cabeza = null;
            JOptionPane.showMessageDialog(null, "Dato eliminado del final");
        } else {
            NodoDoble actual = cabeza;
            while (actual.siguiente != null) {
                actual = actual.siguiente;
            }
            actual.anterior.siguiente = null;
            JOptionPane.showMessageDialog(null, "Dato eliminado del final");
        }
    }

    public void eliminarEspecifico(String dato) {
        if (cabeza == null) {
            JOptionPane.showMessageDialog(null, "Lista vacía");
            return;
        }

        NodoDoble actual = cabeza;
        while (actual != null && !actual.dato.equals(dato)) {
            actual = actual.siguiente;
        }

        if (actual == null) {
            JOptionPane.showMessageDialog(null, "Dato no encontrado");
            return;
        }

        if (actual.anterior != null) {
            actual.anterior.siguiente = actual.siguiente;
        } else {
            cabeza = actual.siguiente;
        }

        if (actual.siguiente != null) {
            actual.siguiente.anterior = actual.anterior;
        }

        JOptionPane.showMessageDialog(null, "Dato eliminado");
    }
    
    public boolean BuscarDato(String elemento) {
    NodoDoble actual = cabeza;
    while (actual != null) {
        if (actual.dato.equals(elemento)) {
            return true;
        }
        actual = actual.siguiente;
    }
    return false;
}
    public void insertarEnPosicion(String dato, int posicion) {
    NodoDoble nuevo = new NodoDoble(dato);

    if (posicion <= 0 || cabeza == null) {
        insertarAlInicio(dato);
        return;
    }

    NodoDoble actual = cabeza;
    int index = 0;

    while (actual.siguiente != null && index < posicion - 1) {
        actual = actual.siguiente;
        index++;
    }

    nuevo.siguiente = actual.siguiente;
    nuevo.anterior = actual;

    if (actual.siguiente != null) {
        actual.siguiente.anterior = nuevo;
    }

    actual.siguiente = nuevo;
}
    public void vaciar() {
        cabeza = null;
    }

    // Obtener tamaño de la lista
    public int tamano() {
        int contador = 0;
        NodoDoble actual = cabeza;
        while (actual != null) {
            contador++;
            actual = actual.siguiente;
        }
        return contador;
    }

}
