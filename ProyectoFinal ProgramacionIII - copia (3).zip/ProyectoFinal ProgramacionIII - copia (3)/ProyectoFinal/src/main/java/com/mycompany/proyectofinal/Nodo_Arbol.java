/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectofinal;

/**
 *
 * @author Piedrasanta
 */
public class Nodo_Arbol {
    public Vehiculo vehiculo;
    public Nodo_Arbol HijoIzquierdo;
    public Nodo_Arbol HijoDerecho;

    public Nodo_Arbol(Vehiculo vehiculo) {
        this.vehiculo = vehiculo;
        this.HijoIzquierdo = null;
        this.HijoDerecho = null;
    }
}
