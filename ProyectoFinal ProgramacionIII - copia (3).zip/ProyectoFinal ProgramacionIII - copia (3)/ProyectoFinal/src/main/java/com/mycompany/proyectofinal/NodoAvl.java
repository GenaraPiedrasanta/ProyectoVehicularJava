/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectofinal;

/**
 *
 * @author Piedrasanta
 */
public class NodoAvl {
    public Vehiculo dato;
    public NodoAvl hijoIzquierdo;
    public NodoAvl hijoDerecho;
    public int altura;

    public NodoAvl(Vehiculo vehiculo) {
        this.dato = vehiculo;
        this.hijoIzquierdo = null;
        this.hijoDerecho = null;
        this.altura = 1; // Nuevo nodo comienza con altura 1
    }
}
