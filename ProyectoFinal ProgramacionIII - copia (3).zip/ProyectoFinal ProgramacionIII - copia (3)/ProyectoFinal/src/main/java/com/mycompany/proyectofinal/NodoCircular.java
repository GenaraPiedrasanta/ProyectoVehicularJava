/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectofinal;

/**
 *
 * @author Piedrasanta
 */
public class NodoCircular {
    public String placa;
    public String dpiAnterior;
    public  String nombreAnterior;
    public String dpiNuevo;
    public String nombreNuevo;
    public String fecha;
    public NodoCircular siguiente;

    public NodoCircular(String placa, String dpiAnterior, String nombreAnterior, String dpiNuevo, String nombreNuevo, String fecha) {
        this.placa = placa;
        this.dpiAnterior = dpiAnterior;
        this.nombreAnterior = nombreAnterior;
        this.dpiNuevo = dpiNuevo;
        this.nombreNuevo = nombreNuevo;
        this.fecha = fecha;
        this.siguiente = null;
    
    }
}
