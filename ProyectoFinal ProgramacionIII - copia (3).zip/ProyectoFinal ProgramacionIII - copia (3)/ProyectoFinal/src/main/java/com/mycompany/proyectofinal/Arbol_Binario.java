/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectofinal;

/**
 *
 * @author Piedrasanta
 */
public class Arbol_Binario {
    Nodo_Arbol raiz;

    public Arbol_Binario() {
        raiz = null;
    }

    public void insertar(Vehiculo v) {
        Nodo_Arbol nuevo = new Nodo_Arbol(v);

        if (raiz == null) {
            raiz = nuevo;
        } else {
            Nodo_Arbol actual = raiz;
            Nodo_Arbol padre;

            while (true) {
                padre = actual;

                if (v.getPlaca().compareTo(actual.vehiculo.getPlaca()) < 0) {
                    actual = actual.HijoIzquierdo;
                    if (actual == null) {
                        padre.HijoIzquierdo = nuevo;
                        return;
                    }
                } else {
                    actual = actual.HijoDerecho;
                    if (actual == null) {
                        padre.HijoDerecho = nuevo;
                        return;
                    }
                }
            }
        }
    }

    // Recorridos 
    public void inOrden(Nodo_Arbol r) {
        if (r != null) {
            inOrden(r.HijoIzquierdo);
            System.out.println(r.vehiculo.getPlaca()); 
            inOrden(r.HijoDerecho);
        }
    }
    
    public Vehiculo buscarPorPlaca(String placa) {
    Nodo_Arbol actual = raiz;

    while (actual != null) {
        int bus = placa.compareTo(actual.vehiculo.getPlaca());

        if (bus == 0) {
            return actual.vehiculo;
        } else if (bus < 0) {
            actual = actual.HijoIzquierdo;
        } else {
            actual = actual.HijoDerecho;
        }
    }
    return null; // fallo
}

}
