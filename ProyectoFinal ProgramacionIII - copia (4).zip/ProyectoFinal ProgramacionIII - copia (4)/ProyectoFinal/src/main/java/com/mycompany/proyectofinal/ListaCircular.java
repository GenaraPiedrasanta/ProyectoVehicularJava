/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectofinal;

/**
 *
 * @author Piedrasanta
 */
public class ListaCircular {
    private NodoCircular inicio, fin;

    public ListaCircular() {
        inicio = null;
        fin = null;
    }

    public boolean EstaVacia() {
        return inicio == null;
    }

    public void agregar(String placa, String dpiAnterior, String nombreAnterior, String dpiNuevo, String nombreNuevo, String fecha) {
        NodoCircular nuevo = new NodoCircular(placa, dpiAnterior, nombreAnterior, dpiNuevo, nombreNuevo, fecha);
        if (EstaVacia()) {
            inicio = nuevo;
            fin = nuevo;
            fin.siguiente = inicio;
        } else {
            fin.siguiente = nuevo;
            fin = nuevo;
            fin.siguiente = inicio;
        }
    }

    public String mostrarTraspasos() {
        if (EstaVacia()) return "Este vehiculo no tiene traspasos registrados.";

        StringBuilder sb = new StringBuilder();
        NodoCircular actual = inicio;
        do {
            sb.append("Fecha: ").append(actual.fecha).append("\n");
            sb.append("DPI Anterior: ").append(actual.dpiAnterior).append("\n");
            sb.append("Nombre Anterior: ").append(actual.nombreAnterior).append("\n");
            sb.append("DPI Nuevo: ").append(actual.dpiNuevo).append("\n");
            sb.append("Nombre Nuevo: ").append(actual.nombreNuevo).append("\n");
            sb.append("-----------------------------\n");
            actual = actual.siguiente;
        } while (actual != inicio);

        return sb.toString();
    }
}
