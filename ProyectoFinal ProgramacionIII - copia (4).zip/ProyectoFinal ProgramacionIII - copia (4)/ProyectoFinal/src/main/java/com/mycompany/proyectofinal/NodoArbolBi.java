/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectofinal;

/**
 *
 * @author Piedrasanta
 */
public class NodoArbolBi {
   
    public int dato;
    public String nombre;
    public NodoArbolBi HijoIzquierdo, HijoDerecho;
    
    
    public NodoArbolBi(int d, String nom){
        this.dato = d;
        this.nombre = nom;
        this.HijoDerecho = null;
        this.HijoIzquierdo = null;
        
    }
}
